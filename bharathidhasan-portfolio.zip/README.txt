Bharathidhasan R — Personal Portfolio Website

FREE DEPLOYMENT:
1. Create/sign in to GitHub.
2. Create a new PUBLIC repository named: YOURUSERNAME.github.io
3. Upload index.html.
4. Open Settings → Pages.
5. Select Deploy from a branch → main → /root → Save.
6. Your site will appear at https://YOURUSERNAME.github.io/

BEFORE PUBLISHING:
Replace YOUR_EMAIL@example.com with your email.
Replace YOUR_LINKEDIN_URL with your LinkedIn profile URL.
